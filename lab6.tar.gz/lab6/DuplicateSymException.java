public class DuplicateSymException extends RuntimeException {

}

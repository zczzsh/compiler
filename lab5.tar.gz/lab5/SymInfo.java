import java.util.*;

/**
 * The SymInfo class defines a symbol-table entry. 
 * Each SymInfo contains a type (a Type).
 */
public class SymInfo {
    private Type type;
    
    public SymInfo(Type type) {
        this.type = type;
    }
    
    public Type getType() {
        return type;
    }
    
    public String toString() {
        return type.toString();
    }
}

/**
 * The FnInfo class is a subclass of the SymInfo class just for functions.
 * The returnType field holds the return type and there are fields to hold
 * information about the parameters.
 */
class FnInfo extends SymInfo {
    
    public FnInfo(Type type, int numparams) {

    }

    public void addFormals(List<Type> L) {

    }
    
    public Type getReturnType() {

    }

    public int getNumParams() {

    }

    public List<Type> getParamTypes() {

    }

    public String toString() {

    }
}

/**
 * The StructInfo class is a subclass of the SymInfo class just for variables 
 * declared to be a struct type. 
 */
class StructInfo extends SymInfo {

    
    public StructInfo(IdNode id) {

    }

    public IdNode getStructType() {

    }    
}

/**
 * The StructDefInfo class is a subclass of the SymInfo class just for the 
 * definition of a struct type. 
 * Each StructDefInfo contains a symbol table to hold information about its 
 * fields.
 */
class StructDefInfo extends SymInfo {
    
    public StructDefInfo(SymTable table) {

    }

    public SymTable getSymTable() {

    }
}

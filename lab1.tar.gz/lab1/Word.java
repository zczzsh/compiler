
/**
 * A class for Word
 */
public class Word {

	
	/**
	 * Builds a Word object with the actual
	 * word (string) 'word' and the information 'info'
	 */
	public Word(String word, Info info) {

	}
	
	/**
	 * Returns the actual word (string)
	 * of this Word
	 */
	public String getWord() {

	}
	
	/**
	 * Returns the information (Info)
	 * of this Word
	 */
	public Info getInfo() {

	}
	
	/**
	 * Returns a String representation
	 * of this Word
	 * (for testing/debugging only)
	 */
	public String toString() {

	}
}


import java.util.*;

/**
 * A class for Symbol Table
 */
public class SymTable {

    /**
     * Create a Symbol Table with one empty scope
     */
    public SymTable() {

    }

    /**
     * Add a declaration (i.e. a pair [name,sym]) in the inner scope
     */
    public void addDecl(String name, SymInfo sym) throws DuplicateSymException, EmptySymTableException {

    }

    /**
     * Add a new inner scope
     */
    public void addScope() {

    }

    /**
     * Lookup for 'name' in the inner scope
     */
    public SymInfo lookupLocal(String name) throws EmptySymTableException {

    }

    /**
     * Lookup for 'name' sequentially in all scopes from inner to outer
     */
    public SymInfo lookupGlobal(String name)  throws EmptySymTableException {

    }

    /**
     * Remove the inner scope
     */
    public void removeScope() throws EmptySymTableException {

    }

    /**
     * Print the Symbol Table on System.out
     */
    public void print() {

    }
}

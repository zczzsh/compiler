
public class EmptySymTableException extends RuntimeException {

}
